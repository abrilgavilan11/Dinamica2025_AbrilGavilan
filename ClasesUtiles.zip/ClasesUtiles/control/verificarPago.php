<?php
/**
 * Archivo para verificar el estado de un pago
 * Este archivo puede ser llamado por AJAX para verificar si un pago fue completado
 */

include_once('../configuracion.php');
header('Content-Type: application/json');

// Obtener referencia del pago
$referencia = $_GET['ref'] ?? '';

if (empty($referencia)) {
    echo json_encode([
        'success' => false,
        'message' => 'Referencia de pago no proporcionada'
    ]);
    exit;
}

// Aquí deberías verificar en tu base de datos o con tu pasarela de pago
// Por ahora, simulamos una respuesta

// Simulación: 50% de probabilidad de pago completado
$pagoCompletado = (rand(0, 1) === 1);

if ($pagoCompletado) {
    echo json_encode([
        'success' => true,
        'estado' => 'completado',
        'message' => 'Pago verificado exitosamente',
        'referencia' => $referencia,
        'fecha' => date('Y-m-d H:i:s')
    ]);
} else {
    echo json_encode([
        'success' => true,
        'estado' => 'pendiente',
        'message' => 'Pago aún no procesado',
        'referencia' => $referencia
    ]);
}
?>
