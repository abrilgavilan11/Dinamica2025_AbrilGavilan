<?php
require_once(__DIR__ . '/../vendor/autoload.php');

use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\RoundBlockSizeMode;
use Endroid\QrCode\Writer\PngWriter;

// Obtener parámetros
$monto = $_GET['monto'] ?? '';
$dni = $_GET['dni'] ?? '';
$nombre = $_GET['nombre'] ?? '';
$descuento = $_GET['descuento'] ?? 0;

// Validar que existan los datos
if (empty($monto) || empty($dni)) {
    die('Faltan datos para generar el QR');
}

// Crear el contenido del QR
// Formato: JSON con los datos del pago
$datosPago = [
    'tipo' => 'pago',
    'monto' => floatval($monto),
    'dni' => $dni,
    'nombre' => $nombre,
    'descuento' => floatval($descuento),
    'fecha' => date('Y-m-d H:i:s'),
    'referencia' => uniqid('PAY-')
];

$contenidoQR = json_encode($datosPago);

$result = Builder::create()
    ->writer(new PngWriter())
    ->writerOptions([])
    ->data($contenidoQR)
    ->encoding(new Encoding('UTF-8'))
    ->errorCorrectionLevel(ErrorCorrectionLevel::Low)
    ->size(300)
    ->margin(10)
    ->roundBlockSizeMode(RoundBlockSizeMode::Margin)
    ->build();

// Configurar headers para imagen PNG
header('Content-Type: ' . $result->getMimeType());

// Enviar la imagen
echo $result->getString();
?>
