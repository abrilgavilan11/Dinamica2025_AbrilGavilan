<?php
include_once('../configuracion.php');
$titulo = 'Juego de Descuento';
$BASE_URL = "http://" . $_SERVER['HTTP_HOST'] . "/qr-payment-system";
include_once('./estructura/header.php');
?>

<div class="main-container">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card card-animated">
                    <div class="card-body p-5">
                        <h2 class="card-title text-center mb-4">
                            <i class="fas fa-gamepad text-warning"></i>
                            ¡Gana tu Descuento!
                        </h2>
                        <p class="text-center text-muted mb-4">
                            Responde correctamente las preguntas para obtener un descuento
                        </p>

                        <div id="juego-container">
                            <!-- Aquí se integrará DialogFlow -->
                            <div class="alert alert-info alert-custom">
                                <i class="fas fa-info-circle me-2"></i>
                                <strong>Integración DialogFlow:</strong> 
                                Aquí irá el chatbot interactivo con DialogFlow para el juego de preguntas.
                            </div>

                            <!-- Placeholder para el juego -->
                            <div class="pregunta-card">
                                <h5 class="mb-3">Pregunta de ejemplo:</h5>
                                <p class="mb-4">¿Cuál es la capital de Argentina?</p>
                                
                                <button class="btn btn-outline-primary opcion-btn">
                                    A) Córdoba
                                </button>
                                <button class="btn btn-outline-primary opcion-btn">
                                    B) Buenos Aires
                                </button>
                                <button class="btn btn-outline-primary opcion-btn">
                                    C) Rosario
                                </button>
                                <button class="btn btn-outline-primary opcion-btn">
                                    D) Mendoza
                                </button>
                            </div>

                            <!-- Botón para simular descuento ganado -->
                            <div class="d-grid gap-2 mt-4">
                                <button class="btn btn-custom-success btn-lg" onclick="aplicarDescuento(15)">
                                    <i class="fas fa-check-circle me-2"></i>
                                    Simular Descuento Ganado (15%)
                                </button>
                                <button class="btn btn-outline-danger" onclick="volverSinDescuento()">
                                    <i class="fas fa-times-circle me-2"></i>
                                    Volver sin Descuento
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
// Verificar que existan datos
window.addEventListener('DOMContentLoaded', function() {
    const clienteData = ClienteData.obtenerDatosCliente();
    const monto = ClienteData.obtenerMonto();

    if (!clienteData || !monto) {
        mostrarAlerta('Faltan datos. Redirigiendo...', 'warning');
        setTimeout(() => {
            window.location.href = 'index.php';
        }, 2000);
    }
});

// Función para aplicar descuento
function aplicarDescuento(porcentaje) {
    ClienteData.guardarDescuento(porcentaje);
    mostrarAlerta(`¡Felicitaciones! Has ganado un ${porcentaje}% de descuento`, 'success');
    
    setTimeout(() => {
        window.location.href = 'resumen.php';
    }, 2000);
}

// Volver sin descuento
function volverSinDescuento() {
    window.location.href = 'resumen.php';
}

/**
 * NOTA: Aquí deberás integrar tu código de DialogFlow
 * 
 * Ejemplo de integración:
 * 1. Cargar el SDK de DialogFlow
 * 2. Configurar el agente con tus credenciales
 * 3. Manejar las respuestas del usuario
 * 4. Según las respuestas correctas, llamar a aplicarDescuento(porcentaje)
 */
</script>

<?php include_once('./estructura/footer.php'); ?>
