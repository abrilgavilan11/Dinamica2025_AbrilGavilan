<footer class="footer mt-auto py-3 bg-light">
        <div class="container text-center">
            <span class="text-muted">
                Sistema de Pago QR - Proyecto de Investigación | 
                Librerías: Endroid QR & DialogFlow
            </span>
        </div>
    </footer>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <!-- JavaScript personalizado -->
    <script src="./assets/js/main.js"></script>
</body>
</html>
