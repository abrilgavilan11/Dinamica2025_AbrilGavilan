<?php
/**
 * Funciones auxiliares del proyecto
 */

/**
 * Sanitiza datos de entrada
 */
function sanitizar($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

/**
 * Valida que un campo no esté vacío
 */
function validarCampoVacio($campo) {
    return !empty($campo);
}

/**
 * Valida formato de DNI (solo números)
 */
function validarDNI($dni) {
    return preg_match('/^[0-9]{7,8}$/', $dni);
}

/**
 * Valida que el monto sea un número válido
 */
function validarMonto($monto) {
    return is_numeric($monto) && $monto > 0;
}

/**
 * Calcula el descuento aplicado
 */
function calcularDescuento($monto, $porcentaje) {
    return $monto - ($monto * ($porcentaje / 100));
}

/**
 * Formatea un monto a moneda
 */
function formatearMoneda($monto) {
    return '$' . number_format($monto, 2, ',', '.');
}
?>
